#ifndef SELECTION_SORT_H
#define SELECTION_SORT_H
#include "ARVORE_HUFFMAN.h"

void selectionSort(tAHuffman *arv, int numElem);

#endif // SELECTION_SORT_H
