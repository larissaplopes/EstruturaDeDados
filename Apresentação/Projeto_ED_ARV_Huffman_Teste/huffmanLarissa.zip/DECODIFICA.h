#ifndef DECODIFICA_H
#define DECODIFICA_H
#include "ARVORE_HUFFMAN.h"

void Decodifica(tNo *t, char *vetorCod);

#endif // DECODIFICA_H


