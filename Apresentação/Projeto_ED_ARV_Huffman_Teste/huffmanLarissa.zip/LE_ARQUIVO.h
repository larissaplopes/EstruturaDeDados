#ifndef LE_ARQUIVO_H
#define LE_ARQUIVO_H
#define TAMANHO_BLOCO 256

extern char* leArquivo(FILE *stream);

#endif // LE_ARQUIVO_H


