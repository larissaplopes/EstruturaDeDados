#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LE_ARQUIVO.h"
#include "DECODIFICA.h"
#include "SELECTION_SORT.h"
#include "ARVORE_HUFFMAN.h"

extern tNo elementoNeutro;
extern int contador;

int main(void) {
	int i,
	    tamanho,
	    cont = 0;
	char *arquivo,
         car,
         *vetorCod;
	tAHuffman arAscii[256];
	tNo *raiz;
	criaFolhas(arAscii);

	FILE *f = fopen("teste.txt", "r");

	if(!(vetorCod = malloc(1 * sizeof(char)))){
        printf("PROBLEMA!");
	}

	tamanho = sizeof(vetorCod)/sizeof(vetorCod[0]);

	arquivo = leArquivo(f);
	for(i = 0; i < strlen(arquivo)+1; i++){
		car = arquivo[i];
		++arAscii[car]->quantidade;
	}
    selectionSort(arAscii, ASCII);
    criaElemNulo(&elementoNeutro);

    for(i = 0; i < ASCII; i++){
		if(arAscii[i]->quantidade){
			break;
		}
	}

	contador = i;

	for(; contador < 255; contador++){
 		CriaRaiz(arAscii);
      selectionSort(arAscii, ASCII);
	}

	raiz = arAscii[contador];
	for(i = 0; i < strlen(arquivo)+1; i++) {
        Percorre(raiz, &arquivo[i], vetorCod, &tamanho, &cont);
	}

	printf("\nCodificacao: \n");
	for(i = 0; i < sizeof(vetorCod)/sizeof(vetorCod[0]);i++){
        if(vetorCod[i]){
            printf("1");
        }else{
            printf("0");
        }
	}
	printf("\n");

	return 0;
}
